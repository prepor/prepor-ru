// English lang variables

tinyMCE.addToLang('NextGEN',{
desc : 'Add NextGEN gallery'
});
