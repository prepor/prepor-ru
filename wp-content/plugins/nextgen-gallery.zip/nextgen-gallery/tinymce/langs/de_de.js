// German lang variables

tinyMCE.addToLang('NextGEN',{
desc : 'Gallerie einfuegen'
});
